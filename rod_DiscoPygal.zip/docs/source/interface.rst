interface package
=================

Submodules
----------

interface.gui\_interface module
-------------------------------

.. automodule:: interface.gui_interface
   :members:
   :undoc-members:
   :show-inheritance:

interface.interface module
--------------------------

.. automodule:: interface.interface
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: interface
   :members:
   :undoc-members:
   :show-inheritance:
