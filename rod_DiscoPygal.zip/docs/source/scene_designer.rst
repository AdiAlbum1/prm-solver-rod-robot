scene\_designer package
=======================

Submodules
----------

scene\_designer.circular\_room module
-------------------------------------

.. automodule:: scene_designer.circular_room
   :members:
   :undoc-members:
   :show-inheritance:

scene\_designer.gui\_scene\_designer module
-------------------------------------------

.. automodule:: scene_designer.gui_scene_designer
   :members:
   :undoc-members:
   :show-inheritance:

scene\_designer.scene\_designer module
--------------------------------------

.. automodule:: scene_designer.scene_designer
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: scene_designer
   :members:
   :undoc-members:
   :show-inheritance:
