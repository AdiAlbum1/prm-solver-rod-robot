docs package
============

Module contents
---------------

.. automodule:: docs
   :members:
   :undoc-members:
   :show-inheritance:
