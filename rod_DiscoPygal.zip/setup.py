from distutils.core import setup

setup(name='rmp',
      version='1.0',
      packages=['gui', 'bindings'],
      )
